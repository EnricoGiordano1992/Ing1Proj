java -jar proj.jar
