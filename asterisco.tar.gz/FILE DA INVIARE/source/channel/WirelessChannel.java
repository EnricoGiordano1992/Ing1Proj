package channel;

public class WirelessChannel extends Channel {

	public WirelessChannel(String channelName) {
		super(channelName);
	}

	@Override
	public void display() {}
}
