package channel;

public class WireChannel extends Channel {

	public WireChannel(String channelName) {
		super(channelName);
	}

	@Override
	public void display() {}
}
