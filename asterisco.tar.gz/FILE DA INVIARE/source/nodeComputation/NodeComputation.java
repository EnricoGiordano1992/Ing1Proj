package nodeComputation;

public interface NodeComputation {
	public float operation(float nodeData, float threshold);
}
